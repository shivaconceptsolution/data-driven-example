package datadriven;

import org.testng.annotations.Test;

public class Hello {
@Test
public void fun()
{
	System.out.println("SCRIPT1");
}
}
